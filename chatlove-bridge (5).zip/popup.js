// Cockpit backend baked in — the ChatLove cockpit lives on the Nickse Hub.
const DEFAULT_BACKEND = "https://nicksehub.com";
// Instalações antigas guardaram o backend da Vercel, que fala com outro banco:
// o código gerado no site não existe lá e o pareamento morre em "Código inválido".
const STALE_BACKEND_RE = /\.vercel\.app$/i;

const $ = (id) => document.getElementById(id);
const get = (keys) => new Promise((r) => chrome.storage.local.get(keys, r));
const set = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));

// Fingerprint da instalação: UUID gerado uma única vez e mantido no storage
// local. Sobrevive ao "Desconectar" de propósito — o backend usa esse id para
// amarrar a instalação a uma única conta do hub.
async function installId() {
  const { install_id } = await get(["install_id"]);
  if (install_id) return install_id;
  const id = crypto.randomUUID();
  await set({ install_id: id });
  return id;
}

function deviceName() {
  const plat = navigator.userAgentData?.platform || navigator.platform || "";
  return plat ? `Chrome · ${plat}` : "Chrome";
}

function showStatus(text, ok) {
  const el = $("status");
  el.textContent = text;
  el.className = "status show " + (ok ? "ok" : "err");
}

async function render() {
  const { device_token, backend_url } = await get(["device_token", "backend_url"]);
  // Pareamento herdado do backend antigo não vale no atual — mostra como desconectado.
  let stale = false;
  try {
    stale = !!backend_url && STALE_BACKEND_RE.test(new URL(backend_url).host);
  } catch {
    stale = !!backend_url;
  }
  if (stale) await set({ backend_url: DEFAULT_BACKEND, device_token: "" });
  const paired = !stale && !!device_token;
  $("pairedBox").style.display = paired ? "flex" : "none";
  $("form").style.display = paired ? "none" : "block";
  $("unpair").style.display = paired ? "block" : "none";
}

$("pair").addEventListener("click", async () => {
  const base = DEFAULT_BACKEND.replace(/\/+$/, "");
  const code = $("code").value.trim().toUpperCase();
  if (!code) return showStatus("Informe o código de pareamento.", false);

  $("pair").disabled = true;
  showStatus("Pareando…", true);
  try {
    const r = await fetch(base + "/api/ext/pair", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code,
        deviceName: deviceName(),
        fingerprint: await installId(),
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      showStatus(data.error || "Falha ao parear.", false);
      $("pair").disabled = false;
      return;
    }
    await set({ backend_url: base, device_token: data.deviceToken });
    chrome.runtime.sendMessage({ type: "PAIRED" }, () => {});
    showStatus("Pareado! A ponte está ativa.", true);
    await render();
  } catch (e) {
    showStatus("Não foi possível conectar ao cockpit.", false);
  } finally {
    $("pair").disabled = false;
  }
});

$("unpair").addEventListener("click", async () => {
  await set({ device_token: "" });
  showStatus("Dispositivo desconectado.", true);
  await render();
});

render();
