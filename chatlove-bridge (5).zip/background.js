// ChatLov Bridge — relay mínimo e benigno.
// Responsabilidades (modelo GGCode: o cockpit no site faz o trabalho via GitHub):
//   1. Reportar ao backend qual projeto Lovable está aberto (id + nome).
//   2. Long-poll de jobs REFRESH_PREVIEW e recarregar a aba do Lovable.
// NÃO captura sessão do Lovable, não intercepta requisições, não executa fetch
// autenticado na conta do usuário.

const get = (keys) => new Promise((r) => chrome.storage.local.get(keys, r));
const set = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));

// O cockpit roda na Railway sob nicksehub.com. Backends antigos (Vercel) falam
// com outro banco — o código de pareamento gerado no site nunca é encontrado lá.
const DEFAULT_BACKEND = "https://nicksehub.com";
const STALE_BACKENDS = [/\.vercel\.app$/i];

async function backendUrl() {
  const { backend_url } = await get(["backend_url"]);
  const stored = String(backend_url || "").replace(/\/+$/, "");
  if (!stored) return DEFAULT_BACKEND;
  let host = "";
  try {
    host = new URL(stored).host;
  } catch {
    return DEFAULT_BACKEND;
  }
  if (STALE_BACKENDS.some((re) => re.test(host))) {
    await set({ backend_url: DEFAULT_BACKEND, device_token: "" });
    return DEFAULT_BACKEND;
  }
  return stored;
}
async function deviceToken() {
  const { device_token } = await get(["device_token"]);
  return device_token || "";
}

// ---- projeto aberto ----
let lastProjectId = null;
let lastProjectName = null;

function cleanTitle(t) {
  return (
    String(t)
      .replace(/\s*[·|\-–]\s*Lovable.*$/i, "")
      .replace(/^Lovable\s*[·|\-–]\s*/i, "")
      .trim() || null
  );
}

function trackProject(url, title) {
  if (!url) return;
  const m =
    String(url).match(/lovable\.(?:dev|app)\/projects\/([a-zA-Z0-9-]+)/) ||
    String(url).match(/projects\/([a-zA-Z0-9-]+)/);
  let changed = false;
  if (m && m[1] && m[1] !== lastProjectId) {
    lastProjectId = m[1];
    changed = true;
  }
  if (title) {
    const clean = cleanTitle(title);
    if (clean && clean !== lastProjectName) {
      lastProjectName = clean;
      changed = true;
    }
  }
  if (changed) reportSoon();
}

chrome.tabs.onUpdated.addListener((_id, _info, tab) => {
  if (tab?.url && /lovable\.(dev|app)/.test(tab.url)) trackProject(tab.url, tab.title);
});
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab?.url && /lovable\.(dev|app)/.test(tab.url)) trackProject(tab.url, tab.title);
  } catch {}
});

let reportTimer = null;
function reportSoon() {
  if (reportTimer) return;
  reportTimer = setTimeout(() => {
    reportTimer = null;
    reportSession().catch(() => {});
  }, 800);
}

async function reportSession() {
  const base = await backendUrl();
  const token = await deviceToken();
  if (!base || !token) return;
  await fetch(base + "/api/ext/session", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
    body: JSON.stringify({ lastProjectId, projectName: lastProjectName }),
  }).catch(() => {});
}

// ---- preview refresh ----
async function findLovableTab() {
  const tabs = await chrome.tabs.query({ url: ["*://*.lovable.dev/*", "*://*.lovable.app/*"] });
  return tabs.find((t) => /projects\//.test(t.url || "")) || tabs[0] || null;
}

// Função INJETADA na aba do Lovable para clicar em "Publish" e confirmar.
// Roda no contexto da página (mundo isolado). Robusta: atravessa shadow DOM,
// casa por aria-label/title/texto. Se não achar o botão, devolve os rótulos dos
// clicáveis visíveis para diagnóstico.
function publishOnLovable() {
  return new Promise((resolve) => {
    const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();
    // Coleta button/a/[role=button]/[role=menuitem] descendo em shadow roots abertos.
    function collect(root, acc, depth) {
      if (!root || depth > 8) return acc;
      let nodes;
      try {
        nodes = root.querySelectorAll("*");
      } catch {
        return acc;
      }
      for (const el of nodes) {
        const role = el.getAttribute && el.getAttribute("role");
        if (el.tagName === "BUTTON" || el.tagName === "A" || role === "button" || role === "menuitem") {
          acc.push(el);
        }
        if (el.shadowRoot) collect(el.shadowRoot, acc, depth + 1);
      }
      return acc;
    }
    const visible = (el) => {
      if (!el) return false;
      if (el.disabled || (el.getAttribute && el.getAttribute("aria-disabled") === "true")) return false;
      const r = el.getBoundingClientRect();
      return r.width > 1 && r.height > 1;
    };
    const label = (el) =>
      norm((el.getAttribute && (el.getAttribute("aria-label") || el.getAttribute("title"))) || el.textContent || "");
    // Bloqueia SÓ a AÇÃO "Unpublish"/excluir (o menu ⋮ tem "Unpublish"). Importante:
    // o próprio botão de publicar, quando há mudanças, se chama "Publish, unpublished
    // changes available" — por isso usamos \bunpublish\b (não casa "unpublished").
    const safe = (e) => !/\bunpublish\b|despublicar|\bdelete\b|deletar|excluir/.test(label(e));
    const findIn = (list, texts, exclude) => {
      for (const t of texts) {
        const h = list.find((e) => e !== exclude && safe(e) && label(e) === t);
        if (h) return h;
      }
      for (const t of texts) {
        const h = list.find((e) => e !== exclude && safe(e) && label(e).includes(t));
        if (h) return h;
      }
      return null;
    };

    const confirmTexts = ["publish changes", "publicar alteraç", "publish", "publicar", "update", "atualizar", "deploy", "republish", "republicar", "confirm", "confirmar"];
    // Texto que o Lovable mostra QUANDO O DEPLOY CONCLUI e o site está no ar.
    const DONE_RE = /(your website was updated|website was updated|website updated|site foi atualizado|seu site foi atualizado|site atualizado com sucesso)/i;
    // Nada a publicar (já está no ar). ESTRITO: só o texto explícito do Lovable,
    // para não concluir "sem alterações" cedo demais enquanto o diálogo monta.
    const NOCHANGE_RE = /(your website is up to date|no unpublished changes|no changes since published|nenhuma altera(ç|c)|sem altera(ç|c))/i;
    const MAX_WAIT_MS = 120000;

    // Texto da página inteira (inclui shadow roots abertos e modais em portal).
    const pageText = () => {
      let t = "";
      try {
        t = document.body ? document.body.innerText : "";
      } catch {}
      const walk = (root, d) => {
        if (!root || d > 8) return;
        let nodes;
        try {
          nodes = root.querySelectorAll("*");
        } catch {
          return;
        }
        for (const el of nodes) {
          if (el.shadowRoot) {
            try {
              t += " " + el.shadowRoot.textContent;
            } catch {}
            walk(el.shadowRoot, d + 1);
          }
        }
      };
      try {
        walk(document, 0);
      } catch {}
      return t.toLowerCase();
    };

    let phase = "find";
    let openBtn = null;
    let confirmAt = 0;
    let tries = 0;
    const timer = setInterval(() => {
      tries++;
      const all = collect(document, [], 0).filter(visible);
      if (phase === "find") {
        openBtn = findIn(all, ["publish", "publicar"]);
        if (openBtn) {
          openBtn.click();
          phase = "confirm";
          tries = 0;
        } else if (tries >= 50) {
          clearInterval(timer);
          const labels = [...new Set(all.map(label).filter(Boolean))].slice(0, 60);
          resolve({ ok: false, error: "Botão Publish não encontrado no Lovable", labels, clickables: all.length });
        }
      } else if (phase === "confirm") {
        const pcTexts = ["publish changes", "publicar alterações", "publicar alteração"];
        // Prioridade: clicar no "Publish changes" HABILITADO e visível assim que
        // ele renderizar (all já filtra habilitados+visíveis).
        const enabled = findIn(all, pcTexts, openBtn);
        if (enabled) {
          enabled.click();
          phase = "wait";
          confirmAt = Date.now();
          tries = 0;
        } else if (NOCHANGE_RE.test(pageText())) {
          // Só o texto EXPLÍCITO "Your website is up to date" conta como sem-alterações.
          clearInterval(timer);
          resolve({ ok: true, confirmed: true, noChanges: true });
        } else if (tries >= 150) {
          // ~30s sem botão habilitado nem sinal de "up to date" — segue para a espera.
          phase = "wait";
          confirmAt = Date.now();
          tries = 0;
        }
      } else {
        // Espera EXATAMENTE o Lovable confirmar "site atualizado / no ar".
        const txt = pageText();
        const waited = Date.now() - confirmAt;
        if (DONE_RE.test(txt)) {
          clearInterval(timer);
          resolve({ ok: true, confirmed: true, waitedMs: waited });
        } else if (waited > 4000 && NOCHANGE_RE.test(txt)) {
          clearInterval(timer);
          resolve({ ok: true, confirmed: true, noChanges: true, waitedMs: waited });
        } else if (waited >= MAX_WAIT_MS) {
          // Não confirmou o deploy: FALHA honesta (não reporta "atualizado").
          clearInterval(timer);
          resolve({ ok: false, error: "Lovable não confirmou o deploy a tempo.", timedOut: true, waitedMs: waited, sample: txt.slice(0, 400) });
        }
      }
    }, 200);
  });
}

async function runJob(job) {
  // Recarregar a aba do Lovable (preview) após um commit.
  if (job.kind === "REFRESH_PREVIEW") {
    const tab = await findLovableTab();
    if (!tab) return { status: 0, ok: false, data: "", error: "Nenhuma aba do Lovable aberta." };
    try {
      await chrome.tabs.reload(tab.id, { bypassCache: true });
      return { status: 200, ok: true, data: "" };
    } catch (e) {
      return { status: 0, ok: false, data: "", error: String(e && e.message ? e.message : e) };
    }
  }
  // Publicar as alterações no Lovable (para o site publicado ficar atualizado).
  if (job.kind === "PUBLISH") {
    const tab = await findLovableTab();
    if (!tab) {
      return { status: 0, ok: false, data: "", error: "Abra o Lovable para publicar." };
    }
    // projectId vem no job — garante publicar no EDITOR do projeto certo (a aba
    // pode ter ido parar no dashboard/lista, onde não há botão Publish).
    let projectId = null;
    try {
      const req = typeof job.request === "string" ? JSON.parse(job.request) : job.request || {};
      projectId = req.projectId || null;
    } catch {}
    try {
      const url = tab.url || "";
      const rightProject = projectId
        ? url.includes("/projects/" + projectId)
        : /lovable\.dev\/projects\/[^/?#]+/.test(url);
      if (projectId && !rightProject) {
        // Navega a aba para o editor do projeto e espera montar.
        await chrome.tabs.update(tab.id, { url: "https://lovable.dev/projects/" + projectId });
        await waitTabComplete(tab.id, 30000);
      } else {
        // Já está no projeto: só garante que não está descarregada/carregando.
        const info = await chrome.tabs.get(tab.id);
        if (info.discarded || info.status !== "complete") {
          try {
            await chrome.tabs.reload(tab.id);
          } catch {}
          await waitTabComplete(tab.id, 25000);
        }
      }
      // Folga extra para o React do editor montar antes de procurar o botão.
      await sleep(1500);
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: publishOnLovable,
      });
      const r = (res && res.result) || {};
      return {
        status: r.ok ? 200 : 0,
        ok: !!r.ok,
        data: JSON.stringify(r),
        error: r.ok ? undefined : r.error || "Falha ao publicar no Lovable",
      };
    } catch (e) {
      return { status: 0, ok: false, data: "", error: String(e && e.message ? e.message : e) };
    }
  }
  // Qualquer outro kind é ignorado (compatibilidade: marca como concluído).
  return { status: 0, ok: true, data: "" };
}

// ---- long-poll ----
let looping = false;
async function loop() {
  if (looping) return;
  looping = true;
  try {
    while (true) {
      const base = await backendUrl();
      const token = await deviceToken();
      if (!base || !token) {
        await sleep(3000);
        continue;
      }
      let job = null;
      try {
        const r = await fetch(base + "/api/ext/jobs", {
          headers: { Authorization: "Bearer " + token },
        });
        if (r.status === 200) job = (await r.json()).job;
        else if (r.status === 401) {
          // Device revogado (repareamento em outro navegador ou corte pelo admin).
          await set({ device_token: "" });
          await sleep(5000);
          continue;
        }
      } catch {
        await sleep(3000);
        continue;
      }
      if (!job) continue; // 204 timeout — re-poll imediatamente
      const result = await runJob(job);
      await fetch(base + "/api/ext/jobs/" + job.id + "/result", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
        body: JSON.stringify(result),
      }).catch(() => {});
    }
  } finally {
    looping = false;
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// Espera a aba terminar de carregar (status 'complete' e não descartada), com
// uma folga para o app React montar antes de injetarmos o script de publish.
async function waitTabComplete(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (!t.discarded && t.status === "complete") {
        await sleep(1500);
        return;
      }
    } catch {
      return;
    }
    await sleep(400);
  }
}

// Mantém o loop vivo entre wakeups do service worker.
chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => {
  loop();
  reportSession().catch(() => {});
});
chrome.runtime.onStartup.addListener(() => loop());
chrome.runtime.onInstalled.addListener(() => loop());
loop();

// O popup dispara um report imediato após parear.
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg?.type === "PAIRED") {
    loop();
    reportSession().then(() => reply({ ok: true }));
    return true;
  }
});
